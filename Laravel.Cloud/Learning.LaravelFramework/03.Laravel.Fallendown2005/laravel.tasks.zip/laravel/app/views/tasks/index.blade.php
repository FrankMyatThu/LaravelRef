@extends('layouts.master')
@section('content')

<div class="col-md-12" style="margin-top:50px;">
	{{ link_to_route('tasks.create', 'Add a new task', null, array('class' => 'btn btn-primary')) }}
</div>
@if($tasks->count())
	<h4>These are your current tasks</h4>
	<div class="col-md-8">		
		<table class="table table-bordered table-striped">
			<thead>
				<tr>
					<th>Task</th>
					<th>Completed</th>
					<th>Created</th>
					<th>Edit</th>
					<th>Delete</th>
				</tr>
			</thead>
			<tbody>
				@foreach($tasks as $task)
					<tr>
						<td>{{ $task->task }}</td>
						<td> 
							@if($task->completed == 0)
								<span class="label label-danger">Not Completed</span>
							@else
								<span class="label label-success">Completed</span>
								<span class="label label-success"> {{ Carbon::createFromTimestamp(strtotime($task->updated_at))->diffForHumans() }} </span>
							@endif
						</td>
						<td><span class="label label-info"> {{ Carbon::createFromTimestamp(strtotime($task->created_at))->diffForHumans() }} </span></td>
						<td> {{ link_to_route('tasks.edit', 'Edit', array($task->id), array('class' => 'btn btn-warning')) }} </td>
						<td>
							{{ Form::open(array('method' => 'DELETE', 'route' => array('tasks.destroy', $task->id))) }}
							{{ Form::submit('Delete', array('class' => 'btn btn-danger')) }}
							{{ Form::close() }}
						</td>
					</tr>
				@endforeach
			</tbody>
		</table>		
	</div>
@else
	<div class="alert alert-info col-md-2" style="margin-top:15px;">
		<strong>Hey There!!</strong>
		You have no tasks!
	</div>
@endif

@stop