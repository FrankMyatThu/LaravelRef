<?php

class TasksController extends \BaseController {

	/**
	 * Display a listing of the resource.
	 * GET /tasks
	 *
	 * @return Response
	 */
	public function index()
	{
		$tasks = Task::orderBy('created_at', 'DESC')->get();
		return View::make('tasks.index')->with('tasks', $tasks);
	}

	/**
	 * Show the form for creating a new resource.
	 * GET /tasks/create
	 *
	 * @return Response
	 */
	public function create()
	{
		return View::make('tasks.create');
	}

	/**
	 * Store a newly created resource in storage.
	 * POST /tasks
	 *
	 * @return Response
	 */
	public function store()
	{
		$input = Input::all();
		$rule = array('task' => 'required');
		$validator = Validator::make($input, $rule);

		if($validator->passes()){
			$task = new Task;
			$task->task = $input['task'];
			$task->completed = 0;
			$task->save();

			return Redirect::route('tasks.index');
		}

		return Redirect::back()->withInput()->withErrors($validator);
	}

	/**
	 * Display the specified resource.
	 * GET /tasks/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		return View::make('tasks.show');
	}

	/**
	 * Show the form for editing the specified resource.
	 * GET /tasks/{id}/edit
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$tasks = Task::find($id);

		if(is_null($tasks)){
			return Redirect::route('tasks.index');
		}

		return View::make('tasks.edit')->with('tasks', $tasks);
	}

	/**
	 * Update the specified resource in storage.
	 * PUT /tasks/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$input = array_except(Input::all(), '_method');
		$rule = array('task' => 'required');
		$validator = Validator::make($input, $rule);

		if($validator->passes()){
			Task::find($id)->update($rule);
			return Redirect::route('tasks.index');
		}

		return Redirect::back()->withInput()->withErrors($validator);
	}

	/**
	 * Remove the specified resource from storage.
	 * DELETE /tasks/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		Task::find($id);
		return Redirect::route('tasks.index');
	}

}