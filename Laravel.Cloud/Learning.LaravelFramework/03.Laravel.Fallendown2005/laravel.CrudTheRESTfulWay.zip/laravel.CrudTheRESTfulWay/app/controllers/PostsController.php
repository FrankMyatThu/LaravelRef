<?php

class PostsController extends BaseController {

	protected $post;

	public function __construct(Post $post)
	{
		$this->post = $post;
	}

	/**
	 * Display a listing of the resource.
	 * GET /posts
	 *
	 * @return Response
	 */
	public function index()
	{
		Log::info("PostsController index()");
		$posts = $this->post->all();
		return View::make('posts.index', compact('posts'));
		// return "This is the index method returned from the PostsController.";
	}

	/**
	 * Show the form for creating a new resource.
	 * GET /posts/create
	 *
	 * @return Response
	 */
	public function create()
	{
		Log::info("PostsController create()");
		return View::make('posts.create');
	}

	/**
	 * Store a newly created resource in storage.
	 * POST /posts
	 *
	 * @return Response
	 */
	public function store()
	{
		Log::info("PostsController store()");
		$input = Input::all();
		$validator = Validator::make($input, Post::$rules);

		if($validator->passes())
		{
			Log::info("PostsController store() validator passed");
			$this->post->create($input);
			Log::info("PostsController store() after insert data");
			return Redirect::route('posts.index');
		}

		return Redirect::route('posts.create')
							->withInput()
							->withErrors($validator)
							->with('message', 'There were validation errors');

	}

	/**
	 * Display the specified resource.
	 * GET /posts/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		Log::info("PostsController show()");
		$post = $this->post->findOrFail($id);
		return View::make('posts.show', compact('post'));
	}

	/**
	 * Show the form for editing the specified resource.
	 * GET /posts/{id}/edit
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$post = $this->post->find($id);
		if(is_null($post))
		{
			return Redirect::route('posts.index');
		}
		return View::make('posts.edit', compact('post'));
	}

	/**
	 * Update the specified resource in storage.
	 * PUT /posts/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		Log::info("PostsController update()");
		$input = array_except(Input::all(), '_method');
		$validator = Validator::make($input, Post::$rules);

		if($validator->passes())
		{
			Log::info("PostsController update() validator passed");
			$post = $this->post->find($id);
			$post->update($input);

			Log::info("PostsController update() after update");
			return Redirect::route('posts.show', $id);

		}

		return Redirect::route('posts.edit', $id)
									->withInput()
									->withErrors($validator)
									->with('message', 'There were validation errors');
	}

	/**
	 * Remove the specified resource from storage.
	 * DELETE /posts/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		$this->post->find($id)->delete();
		return Redirect::route('posts.index');
	}

}