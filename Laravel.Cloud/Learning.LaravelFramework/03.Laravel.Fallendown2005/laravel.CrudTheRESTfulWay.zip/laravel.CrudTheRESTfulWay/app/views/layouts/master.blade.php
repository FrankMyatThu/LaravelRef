<!doctype html>
<html lang="en">
	<head>
		<meta charaset="UTF-8">
		<title></title>
		{{ HTML::script('js/bootstrap.min.js') }} 
		{{ HTML::style('css/style.css') }}
		{{ HTML::style('css/bootstrap.css') }}
        {{ HTML::style('css/bootstrap-theme.css') }}
	</head>
	<body>
		<div class="container" >
			@if(Session::has('message'))
				<div class="flash alert" >
					<p> {{ Session::get('message') }} </p>
				</div>
			@endif

			@yield('content')
		</div>
	</body>
</html>