<?php

class Post extends Eloquent {
	//Log::info("Post model layer");
	protected $fillable = array('author', 'title', 'body');
	public static $rules = array(
			'author' => 'required',
			'title' => 'required',
			'body' => 'required'
		);
}