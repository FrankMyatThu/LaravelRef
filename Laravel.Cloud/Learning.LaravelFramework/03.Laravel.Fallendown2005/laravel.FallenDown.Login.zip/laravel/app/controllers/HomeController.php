<?php

class HomeController extends BaseController {

	/*
	|--------------------------------------------------------------------------
	| Default Home Controller
	|--------------------------------------------------------------------------
	|
	| You may wish to use controllers instead of, or in addition to, Closure
	| based routes. That's great! Here is an example controller method to
	| get you started. To route to this controller, just add the route:
	|
	|	Route::get('/', 'HomeController@showWelcome');
	|
	*/

	public function getIndex(){
		Log::info('[HomeController].[index]');
		return View::make('home.login');
	}

	public function logout(){
		Log::info('[HomeController].[logout]');
		Auth::logout();
		Log::info('[HomeController].[logout] redirect');
		return Redirect::to('/');
	}

	public function getLogin(){
		Log::info('[HomeController].[login]');
		return View::make('home.login');
	}

	public function postLogin()
	{
		$input = Input::all();
		$rules = array('email' => 'required', 'password' => 'required');
		$validator = Validator::make($input, $rules);

		if($validator->fails()){
			return Redirect::to('Login')->withErrors($v);
		}else{
			$credentials = array('email' => $input['email'], 
								'password' => $input['password']);

			if(Auth::attempt($credentials)){
				return Redirect::to('Admin');				
			}else{
				return Redirect::to('Login');
			}
		}
	}

	public function getRegister(){
		Log::info('[HomeController].[register]');
		return View::make('home.register');
	}

	public function postRegister(){

		Log::info('[HomeController].[postRegister]');
		$input = Input::all();

		Log::info('[HomeController].[postRegister] before rule array');
		$rules = array(
						'name' => 'required',
						'email' => 'required|email',
						'password' => 'required');

		Log::info('[HomeController].[postRegister] before validator make');
		$validator = Validator::make($input, $rules);

		Log::info('[HomeController].[postRegister] before passes');
		if($validator->passes()){

			Log::info('[HomeController].[postRegister] after passes');
			$password = $input['password'];
			$password = Hash::make($password);

			Log::info('[HomeController].[postRegister] before user class');
			$user = new User();
			$user->name = $input['name'];
			$user->email = $input['email'];
			$user->password = $password;

			Log::info('[HomeController].[postRegister] before save()');
			$user->save();

			return Redirect::to('Login');
			
		}else{

			return Redirect::to('Register')->withInput()->withErrors($validator);

		}
	}

}
