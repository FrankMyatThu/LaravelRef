<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

/*Route::get('/', function()
{
	return View::make('master');
});


Route::get('login', function()
{
	Log::info('[routes].[login]');
	return View::make('home.login');
});

Route::get('Register', function()
{
	log::info('[routes].[register]');
	return View::make('home.register');
});*/

//Route::get('/login', array('as' => 'getlogin', 'uses' => 'AuthController@getLogin'))->before('guest');


Route::get('/', 'HomeController@getIndex');
Route::get('Login', 'HomeController@getLogin');
Route::post('Login', 'HomeController@postLogin');
Route::get('Logout', 'HomeController@Logout');
Route::get('Register', 'HomeController@getRegister');
Route::post('Register', 'HomeController@postRegister');

Route::group(array('before' => 'auth'), function(){
	Route::get('Admin', 'AdminController@getIndex');
});

