<!doctype html>
<html lang="en">
	<head>
		<meta charaset="UTF-8">
		<title></title>
		{{ HTML::script('js/bootstrap.min.js') }} 
		{{ HTML::style('css/style.css') }}
		{{ HTML::style('css/bootstrap.css') }}
        {{ HTML::style('css/bootstrap-theme.css') }}        
	</head>
	<body>
		<div class="row-fluid"> 
			<div class="span12 well">
				<h1>Some Website</h1>
			</div>
		</div>
		<div class="row-fluid">
			<div class="span3">
				<ul class="nav nav-list">
					@if(Auth::user())
					<li class="nav-header">{{ ucwords(Auth::user()->username) }}</li>
					<li> {{ HTML::Link('post', 'Add Post') }} </li>
					<li> {{ HTML::Link('users', 'View Users') }} </li>
					<li> {{ HTML::Link('Logout', 'Logout') }} </li>
					@else
					<li> {{ HTML::Link('Login', 'login') }} </li>
					@endif
				</ul>
			</div>
			<div class="span9">
				@yield('content')
			</div>
		</div>
	</body>
</html>