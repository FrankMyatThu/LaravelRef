{{ HTML::link('Index', 'Index') }}
&nbsp;
{{ HTML::link('about', 'About') }}