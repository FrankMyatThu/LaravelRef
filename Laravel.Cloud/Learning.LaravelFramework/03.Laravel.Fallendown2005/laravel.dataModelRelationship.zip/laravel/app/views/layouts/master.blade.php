<!doctype html>
<html lang="en">
	<head>
		<meta charaset="UTF-8">
		<title>{{ $title }}</title>
		{{ HTML::script('js/bootstrap.min.js') }} 
		{{ HTML::style('css/style.css') }}
		{{ HTML::style('css/bootstrap.css') }}
        {{ HTML::style('css/bootstrap-theme.css') }}
	</head>
	<body>
		@include('layouts.nav')
	    {{ $content }}
	</body>
</html>