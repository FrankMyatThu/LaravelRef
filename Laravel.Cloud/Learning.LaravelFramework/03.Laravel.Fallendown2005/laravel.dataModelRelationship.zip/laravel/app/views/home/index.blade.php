<h1>User List</h1>
<p>{{ HTML::link('CreatePage', 'Add a new user') }}</p>

@if(isset($users))
	<table class="table table-striped table-bordered table-hover">
		<thead>
			<tr>
				<th>First Name</th>
				<th>Last Name</th>
			</tr>
		</thead>
		<tbody>
			@foreach($users as $UserRow)
				<tr>
					<td> {{ $UserRow->FName }} </td>
					<td> {{ $UserRow->LName }} </td>
				</tr>
			@endforeach
		</tbody>
	</table>
@else
	There are no users
@endif