<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

/*
Route::get('Index', function()
{
	$title = 'I am title';
	$content = View::make('home.index');
	$data = array(
	    'title'  => $title,
	    'content'   => $content
	);
	return View::make('layouts.master')->with($data);	
});

/// Raw Query 
Route::post('Index', function()
{
	$user = DB::select('select * from employees where Country = ?', array('United Kingdom'));
	d($user);

	$input = Input::all();
	DB::insert('insert into test (fname, lname) values (? , ?)', array(e($input['fname']), e($input['lname'])));
});
*/

Route::get('about', function()
{
	$title = 'I am title';
	$content = View::make('home.about');
	$data = array(
	    'title'  => $title,
	    'content'   => $content
	);

	return View::make('layouts.master')->with($data);
});

/// Fluent Query
/*
Route::get('Index', function(){
	
	//$user = DB::table('employees')->get();
	//$user = DB::table('employees')->where('Country', 'United Kingdom')->get();
	//$user = DB::table('employees')->where('Country','=','United Kingdom')->get();
	
	// $user = DB::table('employees')
	// 				->where('EmployeeID', '<', '5')
	// 				->orWhere('Country', 'United Kingdom')
	// 				->get();

	 // $user = DB::table('employees')
	 // 				->whereBetween('EmployeeID', array('3', '5'))
	 // 				->get();

	// $user = DB::table('employees')
	// 				->orderBy('LastName', 'asc')
	// 				->get();

	//d($user);

	// foreach ($user as $UserRow) {
	// 	d($UserRow->LastName);
	// }


	// $user = DB::table('employees')
	// 			->select('Firstname', 'City')
	// 			->get();

	// d($user);
});
*/


/// Fluent Query
/*Route::get('Index', function(){
	$users = DB::table('test')->get();
	$title = 'I am title';
	$content = View::make('home.index')->with('users', $users);
	$data = array(
	    'title'  => $title,
	    'content'   => $content
	);
	return View::make('layouts.master')->with($data);	
});*/

/// Eloquent model way
Route::get('Index', function(){
	//$users = User::all();
	$users = User::orderBy('lname', 'desc')->get();
	$title = 'I am title eloquent';
	$content = View::make('home.index')->with('users', $users);
	$data = array(
	    'title'  => $title,
	    'content'   => $content
	);
	return View::make('layouts.master')->with($data);	
});

/// Fluent Query
Route::post('Index', function(){
	// $input = Input::all();
	// DB::insert('insert into test (fname, lname) values (? , ?)', array(e($input['fname']), e($input['lname'])));
	// DB::table('test')
	// 		->insert(array(e($input['fname']), e($input['lname'])));

	$input = Input::all();
	// $rules = array(
	// 		'fname' => 'required',
	// 		'lname' => 'required'
	// 	);

	// $messages = array(
	// 		'fname.required' => 'A First Name is required',
	// 		'lname.required' => 'A Last Name is required'
	// 	);

	// $validator = Validator::make($input, $rules, $messages);

	$validator = Validator::make($input, User::$rules, User::$messages);

	if($validator->fails()){
		return Redirect::to('CreatePage')
					->withInput()
					->withErrors($validator)
					->with('message');
	}else{
		
		// DB::table('test')
		// 	->insert(array(
		// 			'fname' => e($input['fname']),
		// 			'lname' => e($input['lname'])
		// 		));

		$user = new User;
		$user->fname = e($input['fname']);
		$user->lname = e($input['lname']);
		$user->save();

		return Redirect::to('Index');	
	}
	
});

Route::get('CreatePage', function(){
	$title = 'I am title';
	$content = View::make('home.create');
	$data = array(
	    'title'  => $title,
	    'content'   => $content
	);
	return View::make('layouts.master')->with($data);	
});

Route::get('PostPage', function(){
	$post = Post::find(2);
	$comment = Post::find(2)->ListComment;

	echo '<h1>'.$post->title.'</h1>';
	echo '<p>'.$post->body.'</p>';

	foreach ($comment as $commentRow) {
		echo '<li>'.$commentRow->comment.'</li>';
	}
	
});