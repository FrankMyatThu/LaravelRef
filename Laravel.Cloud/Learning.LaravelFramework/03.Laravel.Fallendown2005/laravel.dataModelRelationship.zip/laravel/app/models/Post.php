<?php

class Post extends Eloquent {
	protected $table = 'posts';
	public $timestamps = false;
	
	public static $rules = array();
	public static $messages = array();	

	public function ListComment()
	{
		return $this->hasMany('Comment', 'posts_id');
	}
}