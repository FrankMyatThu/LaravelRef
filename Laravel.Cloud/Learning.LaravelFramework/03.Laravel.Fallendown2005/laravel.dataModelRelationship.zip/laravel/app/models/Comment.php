<?php

class Comment extends Eloquent {
	protected $table = 'comments';
	public $timestamps = false;
	
	public static $rules = array();
	public static $messages = array();	

	public function PostInfo()
	{
		return $this->belongsTo('Post');
	}
}