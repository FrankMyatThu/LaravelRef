<!DOCTYPE html>
<html>
<head>
	<title>{{ $title }}</title>
	<link rel="stylesheet" href="{{ URL::asset('css/style.css') }}" /> 
</head>
<body>
	<div class="container">
		{{ $content }}	
	</div>
</body>
</html>